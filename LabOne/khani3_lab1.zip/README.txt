//-------------------------------------------------------------
// LAB ONE : TWEET TICKER
// README.txt
// Irene Khan
//-------------------------------------------------------------

Instead of using transitions, I remove the 5th element of
each list every interval when a new list item is added.

