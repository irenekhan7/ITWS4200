//-------------------------------------------------------------
// LAB TWO: WEATHER WIDGET
// README.txt
// Irene Khan
//-------------------------------------------------------------

For the current location, I've included the current temperature
and the weekly highs and lows, using forecast.io's API. 

I couldn't think of something particularly practical to do with 
animations, since there are no links or buttons to hover over and 
since I have not used image icons, so I used CSS3 animations to 
fade the entire widget into view.


